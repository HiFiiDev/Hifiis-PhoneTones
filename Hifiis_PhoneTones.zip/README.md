Custom tones:

Notification: Popcorn
Ringtone: The Big Adventure
Alarm:. Bright Morning